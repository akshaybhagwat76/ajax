﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class AutoCompleteController : Controller
    {
        demoEntities dc = new demoEntities();
        // GET: AutoComplete
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult gettext(string text)
        {
            List<StateVM> stlist = dc.States.Where(x => x.StateName.Contains( text)).Select(x => new StateVM
            {
                StateID=x.StateID,
                StateName  = x.StateName
            }).ToList();
            return new JsonResult { Data = stlist, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }
    }
}