﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
using Newtonsoft.Json;
namespace WebApplication1.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        demoEntities db = new demoEntities();
        public ActionResult Index()
        {
            List<Department> DeptList = db.Departments.ToList();
            ViewBag.ListOfDepartment = new SelectList(DeptList, "DepartmentId", "DepartmentName");
            return View();
        }

        public JsonResult GetStudentList()
        {
            List<StudentVM> StuList = db.Student1.Where(x => x.IsDeleted == false).Select(x => new StudentVM
            {
                StudentId = x.StudentId,
                Name = x.Name,
                Email = x.Email,
                DepartmentName = x.Department.DepartmentName
            }).ToList();

            return Json(StuList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetStudentById(int StudentId)
        {
            Student1 model = db.Student1.Where(x => x.StudentId == StudentId).SingleOrDefault();
            string value = string.Empty;
            value = JsonConvert.SerializeObject(model, Formatting.Indented, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            return Json(value, JsonRequestBehavior.AllowGet);
        }
        public ActionResult jquerydemo()
        {
            return View();
        }
        public ActionResult JsonJquery()
        {
            return View();
        }
    }
}