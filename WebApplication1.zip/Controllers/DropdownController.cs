﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class DropdownController : Controller
    {
        demoEntities dc = new demoEntities();
        public ActionResult Index()
        {
            List<Country> countryList = dc.Countries.ToList();
            ViewData["data"] = countryList;
            return View();
        }
        public JsonResult getstates(int id)
        {
            //dc.Configuration.ProxyCreationEnabled = false;
            var p = dc.States.Where(x => x.CountryID == id).ToList();
            return Json(p, JsonRequestBehavior.AllowGet);
        }
    }
}