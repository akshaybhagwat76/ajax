﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class BaseController : Controller
    {
        // GET: Base
        demoEntities DC = new demoEntities();
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public JsonResult GetEmployees()
        {
            return Json(DC.Employees.ToList(), JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult getID(int EmployeeID)
        {
            var p = (from n in DC.Employees where n.EmployeeID == EmployeeID select n).ToList();
            return Json(p, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult Add(Employee emp)
        {
            var p = DC.Employees.Add(emp);
            DC.SaveChanges();
            return Json(p, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult Delete(int id)
        {
            var del = DC.Employees.Find(id);
            DC.Employees.Remove(del);
            DC.SaveChanges();
            return Json(del, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult Update(int EmployeeID,string FirstName, string LastName,string EmailID,string City,string Country)
        {
            var data = from n in DC.Employees where n.EmployeeID == EmployeeID select n;
            foreach (var item in data)
            {
                item.FirstName = FirstName;
                item.LastName = LastName;
                item.City = City;
                item.Country = Country;
                item.EmailID = EmailID;
            }
            DC.SaveChanges();
            return Json(data,JsonRequestBehavior.AllowGet);
        }                            
    }                                
}