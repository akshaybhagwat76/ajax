﻿$(document).ready(function () {
        alert("Hellow World");
        $('#cls').modal('hide')
        getEmployees();
});


function getEmployees() {
    $.ajax({
        url: "/Base/GetEmployees",
        type: "GET",
        dataType: "json",
        success: function (data) {
            var html = '';
            $.each(data, function (key, item) {
                html += '<tr>';
                html += '<td>' + item.EmployeeID + '</td>';
                html += '<td>' + item.FirstName + '</td>';
                html += '<td>' + item.LastName + '</td>';
                html += '<td>' + item.EmailID + '</td>';
                html += '<td>' + item.City + '</td>';
                html += '<td>' + item.Country + '</td>';
                html += '<td><a href="#" onclick="getbyID(' + item.EmployeeID + '); return false;">Edit</a>  | <a href="#" onclick="del(' + item.EmployeeID + ')">DELETE</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

function getbyID(EmployeeID) {
    $("#btnUpd").hide();
    $('#fnm').css('border-color', 'lightgrey');
    $('#lnm').css('border-color', 'lightgrey');

    $('#email').css('border-color', 'lightgrey');
    $('#cnty').css('border-color', 'lightgrey');
    $('#ct').css('border-color', 'lightgrey');
    debugger;
    var emp = EmployeeID;
    $.ajax({
        type: "GET",
        url: "/Base/getID",
        data:{ EmployeeID:emp},
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            $.each(data, function (key, result) {


             
                $('#empid').val(result.EmployeeID);
                $('#fnm').val(result.FirstName);
                $('#lnm').val(result.LastName);
                $('#email').val(result.EmailID);
                $('#ct').val(result.City);
                $("#cnty").val(result.Country);
                $('#myModal').modal('show');
                $('#btnUpd').show();
                $('#btnAdd').hide();
            });
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

function del(ID) {
    debugger;
    var ans = confirm("Are you sure you want to delete this Record?");
    if (ans) {
        $.ajax({
            url: "/Base/Delete/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {
                getEmployees();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
}

//Add Data Function   
function Add() {

    $("#btnUpd").hide();
    debugger;
    var res = validate();
    if (res==false) {

        return false;
    }
    var empObj = {
        EmployeeID: $('#empid').val(),
        FirstName: $('#fnm').val(),
        LastName:$("#lnm").val(),
        EmailID: $('#email').val(),
        City: $('#ct').val(),
        Country: $('#cnty').val()
    };
    $.ajax({
        url: "/Base/Add",
        data: JSON.stringify(empObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            getEmployees();
            $('#myModal').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}
function validate()
{
  
    var isValid = true;
    if ($("#fnm").val().trim()=="") {

        $("#fnm").css("border-color", "red");
        isValid = false;
    }
    else {
        $("#fnm").css("border-color", " lightgrey");
    }
    if ($("#lnm").val().trim()=="") {
        $("#lnm").css("border-color", "red");
        isValid = false;
    } else {
        $("#lnm").css("border-color", "lightgrey");
    }
    var email = $("#email").val().trim();
    if (email && !isEmail(email)) {
        $("#email").css("border-color","red");
        isValid = false;
    }
    if ($("#ct").val().trim()=="") {
        $("#ct").css("border-color", "red");
        isValid = false;
    } else {
        $("#ct").css("border-color", "lightgrey");
    }
    if ($("#cnty").val().trim()=="") {
        $("#cnty").css("border-color", "red");
        isValid = false;
    } else {
        $("#cnty").css("border-color", "lightgrey");
    }
    return isValid;

}

function Update() {
    var res = validate();
    if (res==false) {

        return false;
    }
    var empObj = {
        EmployeeID: $("#empid").val(),
        FirstName: $("#fnm").val(),
        LastName: $("#lnm").val(),
        EmailID: $("#email").val(),
        City:$("#ct").val(),
        Country:$("#cnty").val()
    }
    $.ajax({
         type: "POST",
         url: "/Base/Update/",
         data: {
             EmployeeID: $("#empid").val(),
             FirstName : $("#fnm").val(),
             LastName  : $("#lnm").val(),
             EmailID   : $("#email").val(),
             City      : $("#ct").val(),
             Country   : $("#cnty").val()
         },
         dataType: "json",
         success: function (data) {
             getEmployees();
             $('#myModal').modal('hide');
             $("#empid").val("");
             $("#fnm").val("");
             $("#lnm").val("");
             $("#email").val("");
             $("#ct").val("");
             $("#cnty").val("");
         },
    });
}
